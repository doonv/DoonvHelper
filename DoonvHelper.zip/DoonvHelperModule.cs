﻿using System;
using Microsoft.Xna.Framework;

namespace Celeste.Mod.DoonvHelper {
    public class DoonvHelperModule : EverestModule {
        public static DoonvHelperModule Instance { get; private set; }

        public override Type SettingsType => typeof(DoonvHelperModuleSettings);
        public static DoonvHelperModuleSettings Settings => (DoonvHelperModuleSettings) Instance._Settings;

        public override Type SessionType => typeof(DoonvHelperModuleSession);
        public static DoonvHelperModuleSession Session => (DoonvHelperModuleSession) Instance._Session;

        public override Type SaveDataType => typeof(DoonvHelperSaveData);
        public static DoonvHelperSaveData SaveData => (DoonvHelperSaveData) Instance._SaveData;

        public DoonvHelperModule() {
            Instance = this;
            
            #if DEBUG
                // debug builds use verbose logging
                Logger.SetLogLevel(nameof(DoonvHelperModule), LogLevel.Verbose);
            #else
                // release builds use info logging to reduce spam in log files
                Logger.SetLogLevel(nameof(DoonvHelperModule), LogLevel.Info);
            #endif
        }

        public override void Load() {
            On.Celeste.Level.Begin += LevelBeginHook;
        }
        public override void Unload() {
            On.Celeste.Level.Begin -= LevelBeginHook;
        }

        private void LevelBeginHook(On.Celeste.Level.orig_Begin orig, Level level)
        {
            orig(level);
            level.Add(new DoonvHelper.Entities.ComfDisplay());
        }
        
    }
}