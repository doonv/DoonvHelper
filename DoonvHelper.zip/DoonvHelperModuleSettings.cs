namespace Celeste.Mod.DoonvHelper {
    public class DoonvHelperModuleSettings : EverestModuleSettings {

    }
}
