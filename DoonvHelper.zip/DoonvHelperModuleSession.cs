namespace Celeste.Mod.DoonvHelper {
    public class DoonvHelperModuleSession : EverestModuleSession {

    }
}
