using System.Collections.Generic;

namespace Celeste.Mod.DoonvHelper
{
    /// <summary>
    /// A unique level identifier.
    /// </summary>
    public struct LevelSideID {
        public string levelSID;
        public AreaMode side;
    }
}
